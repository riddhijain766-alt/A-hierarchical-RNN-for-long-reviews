"""Hierarchical attention RNN vs. flat LSTM for long, structured reviews."""

__version__ = "1.0.0"
