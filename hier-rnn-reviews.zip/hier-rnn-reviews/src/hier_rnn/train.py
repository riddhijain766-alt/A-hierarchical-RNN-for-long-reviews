"""Train ONE model with ONE seed.

    python -m hier_rnn.train --dataset imdb --model hier_gru --seed 0

Artifacts written to  results/<dataset><tag>/<model>/seed<k>/ :
    metrics.json    accuracy / F1 / params / training history
    preds.csv       per-example predictions on the test set (for the subset analysis)
    attention.pkl   per-review sentence-attention vectors (models with attention)
    model.pt        best checkpoint + vocab + config (used by hier_rnn.predict)
and  results/<dataset><tag>/test_annotations.csv  (shared, written once).
"""
from __future__ import annotations

import argparse
import pickle
import time
from dataclasses import asdict

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import f1_score
from tqdm import tqdm

from . import config as C
from .data import DocDataset, Vocab, build_splits, make_loader, to_device
from .models import build_model
from .subsets import load_or_build_annotations
from .utils import count_params, get_device, load_glove_into, save_json, set_seed


@torch.no_grad()
def evaluate(model, loader, device, collect_attn: bool = False) -> dict:
    model.eval()
    loss_sum, preds, probs, labels, attns = 0.0, [], [], [], []
    for batch in loader:
        batch = to_device(batch, device)
        logits, alpha = model(batch)
        loss_sum += F.cross_entropy(logits, batch["y"], reduction="sum").item()
        p = torch.softmax(logits, -1)
        preds.append(p.argmax(-1).cpu())
        probs.append(p[:, 1].cpu())
        labels.append(batch["y"].cpu())
        if collect_attn and alpha is not None:
            a, ns = alpha.cpu().numpy(), batch["n_sents"].cpu().numpy()
            attns.extend(a[i, : ns[i]].astype(np.float32) for i in range(len(ns)))
    preds, probs, labels = (torch.cat(x).numpy() for x in (preds, probs, labels))
    return dict(loss=loss_sum / len(labels), acc=float((preds == labels).mean()),
                f1=float(f1_score(labels, preds, average="macro")),
                preds=preds, probs=probs, labels=labels, attn=attns)


def run(cfg: C.Config, verbose: bool = True) -> dict:
    set_seed(cfg.seed)
    device = get_device(cfg.device)
    splits = build_splits(cfg)
    vocab = Vocab.build(splits["train"].toks, cfg.max_vocab, cfg.min_freq)
    mk = lambda s: DocDataset(splits[s], vocab, cfg.max_sents, cfg.max_words, cfg.truncation)
    train_ds, val_ds, test_ds = mk("train"), mk("val"), mk("test")
    train_dl = make_loader(train_ds, cfg.batch_size, True, cfg.seed, cfg.num_workers)
    val_dl = make_loader(val_ds, cfg.batch_size * 2, False)
    test_dl = make_loader(test_ds, cfg.batch_size * 2, False)

    # shared across models/seeds: structural annotation of the test set
    load_or_build_annotations(cfg.exp_dir / "test_annotations.csv", splits["test"].raws,
                              splits["test"].toks, splits["test"].labels)

    model = build_model(cfg.model, len(vocab), cfg).to(device)
    if cfg.glove:
        n = load_glove_into(model.embedding, vocab.itos, cfg.glove)
        if verbose:
            print(f"GloVe: initialised {n}/{len(vocab)} embeddings")
    n_params = count_params(model)
    if verbose:
        print(f"[{cfg.model} | seed {cfg.seed}] {n_params/1e6:.2f}M params | device={device} | "
              f"train/val/test = {len(train_ds)}/{len(val_ds)}/{len(test_ds)}")

    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="max", factor=0.5, patience=1)

    best_acc, best_state, best_epoch, bad, history = -1.0, None, 0, 0, []
    t0 = time.time()
    for epoch in range(1, cfg.epochs + 1):
        model.train()
        tot, n_seen = 0.0, 0
        for batch in tqdm(train_dl, desc=f"epoch {epoch}", leave=False, disable=not verbose):
            batch = to_device(batch, device)
            logits, _ = model(batch)
            loss = F.cross_entropy(logits, batch["y"])
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            opt.step()
            tot += loss.item() * len(batch["y"])
            n_seen += len(batch["y"])
        val = evaluate(model, val_dl, device)
        sched.step(val["acc"])
        history.append(dict(epoch=epoch, train_loss=tot / n_seen, val_loss=val["loss"],
                            val_acc=val["acc"]))
        if verbose:
            print(f"  epoch {epoch:2d} | train_loss {tot/n_seen:.4f} | val_loss {val['loss']:.4f} "
                  f"| val_acc {val['acc']:.4f}")
        if val["acc"] > best_acc:
            best_acc, best_epoch, bad = val["acc"], epoch, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= cfg.patience:
                break
    train_time = time.time() - t0

    model.load_state_dict(best_state)
    test = evaluate(model, test_dl, device, collect_attn=True)
    if verbose:
        print(f"  TEST acc {test['acc']:.4f} | macro-F1 {test['f1']:.4f} "
              f"(best epoch {best_epoch}, {train_time:.0f}s)")

    out = cfg.run_dir
    out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(dict(idx=np.arange(len(test["labels"])), label=test["labels"],
                      pred=test["preds"], prob_pos=test["probs"])).to_csv(out / "preds.csv", index=False)
    if test["attn"]:
        with open(out / "attention.pkl", "wb") as f:
            pickle.dump(test["attn"], f)
    torch.save(dict(state_dict=best_state, config=asdict(cfg), itos=vocab.itos), out / "model.pt")
    metrics = dict(model=cfg.model, seed=cfg.seed, params=n_params, best_epoch=best_epoch,
                   val_acc=best_acc, test_acc=test["acc"], test_f1=test["f1"],
                   train_time_s=train_time, history=history, config=asdict(cfg))
    save_json(metrics, out / "metrics.json")
    return metrics


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    C.add_args(p)
    run(C.from_namespace(p.parse_args(argv)))


if __name__ == "__main__":
    main()
