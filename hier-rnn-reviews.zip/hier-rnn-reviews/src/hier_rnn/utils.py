from __future__ import annotations

import json
import random
from pathlib import Path

import numpy as np
import torch


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def get_device(name: str = "auto") -> torch.device:
    if name != "auto":
        return torch.device(name)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def count_params(model: torch.nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def save_json(obj, path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=float)


def load_json(path):
    with open(path) as f:
        return json.load(f)


def load_glove_into(embedding: torch.nn.Embedding, itos: list[str], path: str) -> int:
    """Initialise rows of `embedding` from a GloVe text file. Returns #rows found."""
    stoi = {w: i for i, w in enumerate(itos)}
    dim = embedding.weight.shape[1]
    found = 0
    with open(path, encoding="utf8") as f:
        for line in f:
            word, *vec = line.rstrip().split(" ")
            if word in stoi and len(vec) == dim:
                embedding.weight.data[stoi[word]] = torch.tensor([float(x) for x in vec])
                found += 1
    return found
