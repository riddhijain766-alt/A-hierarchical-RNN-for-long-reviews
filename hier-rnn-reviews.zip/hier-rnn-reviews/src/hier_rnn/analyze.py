"""Answer the research question from saved predictions.

    python -m hier_rnn.analyze --exp_dir results/imdb

Outputs (in <exp_dir>/analysis/):
    overall.csv|md            accuracy / F1 / #params per model (mean ± std over seeds)
    subsets.csv|md            accuracy per review type per model
    pairwise_vs_<base>.csv|md Δ accuracy vs the baseline with 95% paired-bootstrap CI
    attention_stats.csv|md    how much attention hier models put on the end of the review
    fig_subsets.png           accuracy by review type
    fig_length.png            accuracy vs review length (quantile bins)
    fig_attention_position.png  where the model attends, by review type
"""
from __future__ import annotations

import argparse
import pickle
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .models import BASELINE
from .subsets import SUBSET_ORDER, subset_mask
from .utils import load_json

MIN_N_WARN = 100


# --------------------------------------------------------------------------- #
def df_to_md(df: pd.DataFrame, index: bool = True) -> str:
    d = df.reset_index() if index else df
    cols = [str(c) for c in d.columns]
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for _, r in d.iterrows():
        lines.append("| " + " | ".join(str(v) for v in r.tolist()) + " |")
    return "\n".join(lines)


def write_table(df: pd.DataFrame, out: Path, name: str, index: bool = True) -> None:
    df.to_csv(out / f"{name}.csv", index=index)
    (out / f"{name}.md").write_text(df_to_md(df, index) + "\n")


def pm(x, scale=100.0, nd=2) -> str:
    x = np.asarray(x, dtype=float) * scale
    return f"{x.mean():.{nd}f} ± {x.std(ddof=1) if len(x) > 1 else 0.0:.{nd}f}"


def _pp(x: float) -> str:
    """fraction -> percentage points string, without '-0.00'."""
    return f"{round(100 * x, 2) + 0.0:.2f}"


def paired_bootstrap(diff: np.ndarray, n_boot: int = 2000, seed: int = 0):
    """95% CI of mean(diff) over examples (percentile bootstrap)."""
    rng = np.random.default_rng(seed)
    n = len(diff)
    means = np.array([diff[rng.integers(0, n, n)].mean() for _ in range(n_boot)])
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


# --------------------------------------------------------------------------- #
def load_runs(exp_dir: Path):
    """-> {model: {seed: dict(metrics=..., correct=bool array, preds=...)}}"""
    runs = {}
    for mdir in sorted(p for p in exp_dir.iterdir() if p.is_dir() and p.name != "analysis"):
        for sdir in sorted(mdir.glob("seed*")):
            if not (sdir / "metrics.json").exists():
                continue
            preds = pd.read_csv(sdir / "preds.csv")
            runs.setdefault(mdir.name, {})[int(sdir.name[4:])] = dict(
                metrics=load_json(sdir / "metrics.json"),
                correct=(preds.pred == preds.label).to_numpy(),
                dir=sdir,
            )
    return runs


def order_models(models) -> list[str]:
    pref = ["flat_lstm", "flat_bilstm", "flat_bilstm_max",
            "hier_gru_noattn", "hier_attn_norec", "hier_gru"]
    return [m for m in pref if m in models] + sorted(m for m in models if m not in pref)


# --------------------------------------------------------------------------- #
def overall_table(runs) -> pd.DataFrame:
    rows = {}
    for m in order_models(runs):
        ms = [r["metrics"] for r in runs[m].values()]
        rows[m] = {"seeds": len(ms), "params(M)": f"{ms[0]['params']/1e6:.2f}",
                   "test acc (%)": pm([x["test_acc"] for x in ms]),
                   "macro-F1 (%)": pm([x["test_f1"] for x in ms]),
                   "val acc (%)": pm([x["val_acc"] for x in ms]),
                   "train time (s)": f"{np.mean([x['train_time_s'] for x in ms]):.0f}"}
    return pd.DataFrame(rows).T.rename_axis("model")


def subset_tables(runs, ann: pd.DataFrame):
    models = order_models(runs)
    names = [s for s in SUBSET_ORDER if s in ann.columns]
    acc_rows, n_rows = {}, {}
    for s in names:
        mask = subset_mask(ann, s)
        n_rows[s] = int(mask.sum())
        cell = {}
        for m in models:
            accs = [r["correct"][mask].mean() for r in runs[m].values()] if mask.any() else [np.nan]
            cell[m] = pm(accs)
        acc_rows[f"{s} (n={mask.sum()})" + (" *" if 0 < mask.sum() < MIN_N_WARN else "")] = cell
    return pd.DataFrame(acc_rows).T.rename_axis("subset (test acc %)"), n_rows


def pairwise_table(runs, ann: pd.DataFrame, base: str, n_boot: int) -> pd.DataFrame:
    rows = []
    for m in order_models(runs):
        if m == base:
            continue
        seeds = sorted(set(runs[m]) & set(runs[base]))
        for s in SUBSET_ORDER:
            if s not in ann.columns:
                continue
            mask = subset_mask(ann, s)
            if mask.sum() < 2:
                continue
            ca = np.mean([runs[m][k]["correct"][mask] for k in seeds], axis=0)    # seed-avg correctness
            cb = np.mean([runs[base][k]["correct"][mask] for k in seeds], axis=0)
            lo, hi = paired_bootstrap(ca - cb, n_boot)
            per_seed = [runs[m][k]["correct"][mask].mean() - runs[base][k]["correct"][mask].mean()
                        for k in seeds]
            rows.append({"model": m, "subset": s, "n": int(mask.sum()),
                         "Δacc (pp)": round(100 * float((ca - cb).mean()), 2),
                         "95% CI (pp)": f"[{_pp(lo)}, {_pp(hi)}]",
                         "CI excludes 0": bool(lo > 0 or hi < 0),
                         "seeds won": f"{sum(d > 0 for d in per_seed)}/{len(seeds)}"})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
def plot_subsets(runs, ann, out: Path) -> None:
    models = order_models(runs)
    names = [s for s in ["all", "short", "long", "consistent", "mixed", "turnaround", "neg_to_pos"]
             if s in ann.columns and subset_mask(ann, s).sum() > 0]
    fig, ax = plt.subplots(figsize=(1.6 * len(names) + 3, 4.2))
    w = 0.8 / len(models)
    for j, m in enumerate(models):
        means, stds = [], []
        for s in names:
            mask = subset_mask(ann, s)
            a = [r["correct"][mask].mean() * 100 for r in runs[m].values()]
            means.append(np.mean(a)); stds.append(np.std(a, ddof=1) if len(a) > 1 else 0)
        ax.bar(np.arange(len(names)) + j * w - 0.4 + w / 2, means, w, yerr=stds, capsize=2, label=m)
    ax.set_xticks(range(len(names)))
    ax.set_xticklabels([f"{s}\n(n={subset_mask(ann, s).sum()})" for s in names], fontsize=8)
    ax.set_ylabel("test accuracy (%)")
    ax.legend(fontsize=7, ncol=len(models), loc="upper center", bbox_to_anchor=(0.5, -0.18))
    lo = min(b.get_height() for b in ax.patches) - 5
    ax.set_ylim(max(0, lo), 100); ax.set_title("Accuracy by review type (mean ± std over seeds)")
    fig.tight_layout(); fig.savefig(out / "fig_subsets.png", dpi=160); plt.close(fig)


def plot_length(runs, ann, out: Path, n_bins: int = 5) -> None:
    bins = pd.qcut(ann.n_tokens, n_bins, duplicates="drop")
    cats = list(bins.cat.categories)
    labels = [f"{int(c.left)}–{int(c.right)}" for c in cats]
    fig, ax = plt.subplots(figsize=(6.5, 4))
    for m in order_models(runs):
        per_bin = []
        for r in runs[m].values():
            per_bin.append([r["correct"][(bins == c).to_numpy()].mean() * 100 for c in cats])
        per_bin = np.array(per_bin)
        sd = per_bin.std(0, ddof=1) if len(per_bin) > 1 else 0
        ax.errorbar(range(len(cats)), per_bin.mean(0), yerr=sd, marker="o", capsize=2, label=m)
    ax.set_xticks(range(len(cats))); ax.set_xticklabels(labels, fontsize=8)
    ax.set_xlabel("review length (tokens, quantile bins)"); ax.set_ylabel("test accuracy (%)")
    ax.legend(fontsize=7); ax.set_title("Accuracy vs. review length")
    fig.tight_layout(); fig.savefig(out / "fig_length.png", dpi=160); plt.close(fig)


def attention_analysis(runs, ann, out: Path, n_bins: int = 5) -> None:
    models = [m for m in order_models(runs)
              if all((r["dir"] / "attention.pkl").exists() for r in runs[m].values())]
    if not models:
        return
    groups = [g for g in ["consistent", "mixed", "turnaround"] if g in ann.columns
              and subset_mask(ann, g).sum() > 0]
    stat_rows, fig, axes = [], None, None
    fig, axes = plt.subplots(1, len(models), figsize=(4.6 * len(models), 3.8), squeeze=False)
    for ax, m in zip(axes[0], models):
        prof = {g: [] for g in groups}
        last20 = {g: [] for g in groups}
        lastsent = {g: [] for g in groups}
        for r in runs[m].values():
            with open(r["dir"] / "attention.pkl", "rb") as f:
                att = pickle.load(f)
            for g in groups:
                idxs = np.flatnonzero(subset_mask(ann, g))
                mass = np.zeros(n_bins); l20, ls = [], []
                for i in idxs:
                    a = att[i]; n = len(a)
                    rel = (np.arange(n) + 0.5) / n
                    np.add.at(mass, np.minimum((rel * n_bins).astype(int), n_bins - 1), a)
                    l20.append(a[rel > 0.8].sum()); ls.append(a[-1])
                prof[g].append(mass / len(idxs)); last20[g].append(np.mean(l20)); lastsent[g].append(np.mean(ls))
        for g in groups:
            ax.plot(np.arange(n_bins), np.mean(prof[g], 0), marker="o", label=f"{g}")
            stat_rows.append({"model": m, "subset": g, "n": int(subset_mask(ann, g).sum()),
                              "attn mass on final 20% of sentences": pm(last20[g], 1, 3),
                              "attn on last sentence": pm(lastsent[g], 1, 3)})
        ax.axhline(1 / n_bins, color="gray", ls=":", lw=1)
        ax.set_xticks(range(n_bins))
        ax.set_xticklabels([f"{int(100*i/n_bins)}–{int(100*(i+1)/n_bins)}%" for i in range(n_bins)], fontsize=7)
        ax.set_xlabel("position in review"); ax.set_ylabel("mean attention mass")
        ax.set_title(m, fontsize=9); ax.legend(fontsize=7)
    fig.suptitle("Sentence attention by position (dotted = uniform)", fontsize=10)
    fig.tight_layout(); fig.savefig(out / "fig_attention_position.png", dpi=160); plt.close(fig)
    write_table(pd.DataFrame(stat_rows), out, "attention_stats", index=False)


# --------------------------------------------------------------------------- #
def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("--exp_dir", required=True, help="e.g. results/imdb")
    ap.add_argument("--baseline", default=BASELINE)
    ap.add_argument("--n_boot", type=int, default=2000)
    args = ap.parse_args(argv)

    exp = Path(args.exp_dir)
    out = exp / "analysis"
    out.mkdir(exist_ok=True)
    ann = pd.read_csv(exp / "test_annotations.csv")
    runs = load_runs(exp)
    if not runs:
        raise SystemExit(f"no finished runs found in {exp}")

    ov = overall_table(runs); write_table(ov, out, "overall")
    sub, _ = subset_tables(runs, ann); write_table(sub, out, "subsets")
    print("\n=== Overall ===\n" + df_to_md(ov)); print("\n=== By review type ===\n" + df_to_md(sub))
    print("(* = fewer than %d reviews: interpret with caution)" % MIN_N_WARN)

    if args.baseline in runs and len(runs) > 1:
        pw = pairwise_table(runs, ann, args.baseline, args.n_boot)
        write_table(pw, out, f"pairwise_vs_{args.baseline}", index=False)
        print(f"\n=== Δ accuracy vs {args.baseline} (paired bootstrap) ===\n" + df_to_md(pw, index=False))
    plot_subsets(runs, ann, out); plot_length(runs, ann, out); attention_analysis(runs, ann, out)
    print(f"\nTables and figures written to {out}/")


if __name__ == "__main__":
    main()
