"""Inspect a trained model on any review: prediction + per-sentence attention.

    python -m hier_rnn.predict --ckpt results/imdb/hier_gru/seed0/model.pt \
        --text "The first hour was a slog. The dialogue was clumsy. But the ending was superb."
    python -m hier_rnn.predict --ckpt ... --file review.txt --html out.html

Note: attention weights show where the model *looks*, which is informative but not
a guaranteed causal explanation (Jain & Wallace, 2019).
"""
from __future__ import annotations

import argparse
import html as _html

import torch

from . import config as C
from .data import Vocab, collate_docs, keep_indices, process_text
from .models import build_model


def load_checkpoint(path: str, device: str = "cpu"):
    ck = torch.load(path, map_location=device)
    cfg = C.from_dict(ck["config"])
    vocab = Vocab(ck["itos"])
    model = build_model(cfg.model, len(vocab), cfg)
    model.load_state_dict(ck["state_dict"])
    return model.eval(), vocab, cfg


@torch.no_grad()
def predict_review(model, vocab, cfg, text: str):
    raws, toks = process_text(text)
    kept = keep_indices(len(toks), cfg.max_sents, cfg.truncation)
    doc = [[vocab.encode(w) for w in toks[i][: cfg.max_words]] for i in kept]
    logits, alpha = model(collate_docs([(doc, 0, 0)]))
    prob = torch.softmax(logits, -1)[0]
    att = alpha[0, : len(kept)].tolist() if alpha is not None else None
    return dict(prob_pos=float(prob[1]), label="positive" if prob[1] > 0.5 else "negative",
                sentences=[raws[i] for i in kept], attention=att)


def to_html(res: dict) -> str:
    rows = []
    for i, s in enumerate(res["sentences"]):
        a = res["attention"][i] if res["attention"] else 0
        rows.append(f'<p style="background:rgba(255,140,0,{min(1, a * 2.5):.2f});padding:4px">'
                    f'<small>{a:.2f}</small> {_html.escape(s)}</p>')
    head = f"<h3>{res['label']} (P(pos)={res['prob_pos']:.3f})</h3>"
    return f"<html><body style='font-family:sans-serif;max-width:800px'>{head}{''.join(rows)}</body></html>"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--text"); ap.add_argument("--file"); ap.add_argument("--html")
    a = ap.parse_args(argv)
    text = a.text if a.text else open(a.file, encoding="utf8").read()
    model, vocab, cfg = load_checkpoint(a.ckpt)
    res = predict_review(model, vocab, cfg, text)
    print(f"\nprediction: {res['label']}  (P(positive) = {res['prob_pos']:.3f})  [{cfg.model}]\n")
    for i, s in enumerate(res["sentences"]):
        if res["attention"]:
            w = res["attention"][i]
            print(f"{w:5.2f} {'█' * int(round(w * 40)):<40} {s}")
        else:
            print(f"      {s}")
    if a.html:
        open(a.html, "w", encoding="utf8").write(to_html(res))
        print(f"\nwrote {a.html}")


if __name__ == "__main__":
    main()
