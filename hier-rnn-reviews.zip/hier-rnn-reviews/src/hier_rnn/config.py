"""Single source of truth for every hyper-parameter and CLI flag."""
from __future__ import annotations

import argparse
from dataclasses import dataclass, fields
from pathlib import Path


@dataclass
class Config:
    # ---- data -------------------------------------------------------------
    dataset: str = "imdb"          # imdb | yelp_polarity | amazon_polarity | synthetic | csv
    data_dir: str = "data"
    cache_dir: str = "data/cache"
    results_dir: str = "results"
    tag: str = ""                  # appended to the experiment folder name
    csv_dir: str = None            # folder with train.csv / test.csv (columns: text,label)
    max_train: int = None          # subsample the training set (speed)
    max_test: int = None           # subsample the test set
    val_frac: float = 0.1
    data_seed: int = 13            # fixes the split for ALL models/seeds
    n_synth_train: int = 6000
    n_synth_test: int = 2000

    # ---- preprocessing / truncation ---------------------------------------
    max_vocab: int = 30000
    min_freq: int = 3
    max_sents: int = 30            # sentences kept per review
    max_words: int = 50            # words kept per sentence
    truncation: str = "head_tail"  # head | tail | head_tail (which sentences to keep)

    # ---- model ------------------------------------------------------------
    model: str = "hier_gru"
    emb_dim: int = 200
    word_hidden: int = 128         # per direction -> 256-d sentence vector
    sent_hidden: int = 256
    flat_hidden: int = 256
    word_pooling: str = "last"     # last | mean | max | attn  (hierarchical models)
    dropout: float = 0.3
    glove: str = None              # optional path to glove.*.txt

    # ---- optimisation -----------------------------------------------------
    epochs: int = 10
    batch_size: int = 64
    lr: float = 2e-3
    weight_decay: float = 1e-2
    grad_clip: float = 5.0
    patience: int = 3              # early stopping on validation accuracy
    seed: int = 0
    device: str = "auto"
    num_workers: int = 0

    @property
    def exp_dir(self) -> Path:
        return Path(self.results_dir) / f"{self.dataset}{self.tag}"

    @property
    def run_dir(self) -> Path:
        return self.exp_dir / self.model / f"seed{self.seed}"


_OPTIONAL_TYPES = {"csv_dir": str, "max_train": int, "max_test": int, "glove": str}


def add_args(parser: argparse.ArgumentParser, skip=()) -> argparse.ArgumentParser:
    """Expose every Config field as a --flag."""
    defaults = Config()
    for f in fields(Config):
        if f.name in skip:
            continue
        default = getattr(defaults, f.name)
        flag = f"--{f.name}"
        if isinstance(default, bool):
            parser.add_argument(flag, action=argparse.BooleanOptionalAction, default=default)
        elif default is None:
            parser.add_argument(flag, type=_OPTIONAL_TYPES[f.name], default=None)
        else:
            parser.add_argument(flag, type=type(default), default=default)
    return parser


def from_namespace(ns: argparse.Namespace) -> Config:
    names = {f.name for f in fields(Config)}
    return Config(**{k: v for k, v in vars(ns).items() if k in names})


def from_dict(d: dict) -> Config:
    names = {f.name for f in fields(Config)}
    return Config(**{k: v for k, v in d.items() if k in names})
