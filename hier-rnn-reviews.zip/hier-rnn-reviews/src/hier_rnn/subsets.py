"""Operational definitions of the three review types in the research question.

Each test review is annotated using **VADER sentence polarity** (an independent,
lexicon-based tool that is NOT one of the models being compared), computed on the
full un-truncated review:

long          number of tokens >= 75th percentile of the test set
short         number of tokens <= 25th percentile
mixed         >= `min_polar` polar sentences (|compound| >= `polar_thr`) and the
              minority polarity makes up >= `minority_share` of them
turnaround    the first `early_frac` of the sentences and the remainder have
              opposite mean polarity (both |mean| >= `turn_min_mag`) AND the late
              part agrees with the gold label, i.e. the conclusion decides the label
neg_to_pos    turnaround with gold label positive  (negative discussion, positive end)
pos_to_neg    turnaround with gold label negative
consistent    neither mixed nor turnaround  (control group)
long_mixed / long_turnaround    intersections with `long`

Subsets overlap (a review can be long AND mixed). Thresholds are heuristics, so
every parameter can be changed and the whole analysis is re-run from the cache.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

SUBSET_ORDER = ["all", "short", "long", "consistent", "mixed", "turnaround",
                "neg_to_pos", "pos_to_neg", "long_mixed", "long_turnaround"]


@dataclass
class SubsetParams:
    polar_thr: float = 0.25
    min_polar: int = 4
    minority_share: float = 0.30
    early_frac: float = 0.60
    turn_min_sents: int = 4
    turn_min_mag: float = 0.10
    long_q: float = 0.75
    short_q: float = 0.25


def sentence_polarities(raws: list[str], analyzer) -> list[float]:
    return [analyzer.polarity_scores(s)["compound"] if s else 0.0 for s in raws]


def structure_features(pol: np.ndarray, label: int, p: SubsetParams) -> dict:
    n = len(pol)
    n_pos, n_neg = int((pol > p.polar_thr).sum()), int((pol < -p.polar_thr).sum())
    n_polar = n_pos + n_neg
    mixed = n_polar >= p.min_polar and min(n_pos, n_neg) / n_polar >= p.minority_share

    k = max(1, int(np.ceil(p.early_frac * n)))
    early = float(pol[:k].mean())
    late = float(pol[k:].mean()) if k < n else float("nan")
    turn = False
    if n >= p.turn_min_sents and k < n:
        gold_sign = 1 if label == 1 else -1
        turn = (abs(early) >= p.turn_min_mag and abs(late) >= p.turn_min_mag
                and np.sign(early) != np.sign(late) and np.sign(late) == gold_sign)
    return dict(n_sents=n, n_pos=n_pos, n_neg=n_neg, early_mean=early, late_mean=late,
                mixed=bool(mixed), turnaround=bool(turn),
                neg_to_pos=bool(turn and label == 1), pos_to_neg=bool(turn and label == 0))


def annotate(raws_list: list[list[str]], toks_list: list[list[list[str]]], labels: list[int],
             p: SubsetParams | None = None) -> pd.DataFrame:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

    p = p or SubsetParams()
    analyzer = SentimentIntensityAnalyzer()
    rows = []
    for i, (raws, toks, y) in enumerate(zip(raws_list, toks_list, labels)):
        pol = np.array(sentence_polarities(raws, analyzer), dtype=float)
        row = dict(idx=i, label=int(y), n_tokens=int(sum(len(s) for s in toks)),
                   polarity=json.dumps([round(float(x), 3) for x in pol]))
        row.update(structure_features(pol, int(y), p))
        rows.append(row)
    df = pd.DataFrame(rows)

    df["long"] = df.n_tokens >= df.n_tokens.quantile(p.long_q)
    df["short"] = df.n_tokens <= df.n_tokens.quantile(p.short_q)
    df["consistent"] = ~(df.mixed | df.turnaround)
    df["long_mixed"] = df["long"] & df.mixed
    df["long_turnaround"] = df["long"] & df.turnaround
    df["all"] = True
    return df


def load_or_build_annotations(path: str | Path, raws_list, toks_list, labels,
                              p: SubsetParams | None = None) -> pd.DataFrame:
    path = Path(path)
    if path.exists():
        return pd.read_csv(path)
    df = annotate(raws_list, toks_list, labels, p)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return df


def subset_mask(df: pd.DataFrame, name: str) -> np.ndarray:
    return df[name].to_numpy(dtype=bool)
