"""Models.

Flat baselines (one recurrent pass over all tokens of the review)
    flat_lstm        unidirectional LSTM, last hidden state      <- THE baseline
    flat_bilstm      bidirectional LSTM, last hidden states
    flat_bilstm_max  bidirectional LSTM + max-pooling over time   (stronger baseline)

Hierarchical models (words -> sentences -> document)
    hier_gru         word BiGRU -> sentence GRU -> sentence attention   (proposed model)
    hier_gru_noattn  same, but classify from the sentence-GRU final state (ablate attention)
    hier_attn_norec  word BiGRU -> sentence attention, NO sentence GRU    (ablate recurrence)

The two ablations answer *why* a hierarchical model wins (or doesn't): is it the
sentence boundary structure, the sentence-level recurrence, or the attention?
"""
from __future__ import annotations

import torch
import torch.nn as nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

from .config import Config

BASELINE = "flat_lstm"

MODEL_SPECS = {
    "flat_lstm":       dict(kind="flat", cell="lstm", bidirectional=False, pooling="last"),
    "flat_bilstm":     dict(kind="flat", cell="lstm", bidirectional=True, pooling="last"),
    "flat_bilstm_max": dict(kind="flat", cell="lstm", bidirectional=True, pooling="max"),
    "hier_gru":        dict(kind="hier", use_sent_rnn=True, sent_pool="attn"),
    "hier_gru_noattn": dict(kind="hier", use_sent_rnn=True, sent_pool="last"),
    "hier_attn_norec": dict(kind="hier", use_sent_rnn=False, sent_pool="attn"),
}


def _pack(x: torch.Tensor, lengths: torch.Tensor):
    return pack_padded_sequence(x, lengths.detach().cpu(), batch_first=True, enforce_sorted=False)


def _masked_mean(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    m = mask.unsqueeze(-1).to(x.dtype)
    return (x * m).sum(1) / m.sum(1).clamp(min=1)


def _masked_max(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    return x.masked_fill(~mask.unsqueeze(-1), -1e9).max(1).values


class AdditiveAttention(nn.Module):
    """alpha_i = softmax_i( c . tanh(W h_i + b) );  out = sum_i alpha_i h_i
    (Bahdanau-style, as used in Yang et al. 2016). Padding positions get alpha=0."""

    def __init__(self, in_dim: int, att_dim: int | None = None):
        super().__init__()
        att_dim = att_dim or in_dim
        self.proj = nn.Linear(in_dim, att_dim)
        self.ctx = nn.Linear(att_dim, 1, bias=False)

    def forward(self, h: torch.Tensor, mask: torch.Tensor):
        scores = self.ctx(torch.tanh(self.proj(h))).squeeze(-1)
        scores = scores.masked_fill(~mask, float("-inf"))
        alpha = torch.softmax(scores, dim=-1)
        return (alpha.unsqueeze(-1) * h).sum(1), alpha


def _make_embedding(vocab_size: int, emb_dim: int) -> nn.Embedding:
    emb = nn.Embedding(vocab_size, emb_dim, padding_idx=0)
    nn.init.normal_(emb.weight, 0.0, 0.1)
    with torch.no_grad():
        emb.weight[0].zero_()
    return emb


# --------------------------------------------------------------------------- #
# Flat baselines
# --------------------------------------------------------------------------- #
class FlatRNN(nn.Module):
    has_attention = False

    def __init__(self, vocab_size, emb_dim=200, hidden=256, cell="lstm", bidirectional=False,
                 pooling="last", dropout=0.3, num_classes=2):
        super().__init__()
        self.pooling, self.bidirectional, self.cell = pooling, bidirectional, cell
        self.embedding = _make_embedding(vocab_size, emb_dim)
        rnn_cls = nn.LSTM if cell == "lstm" else nn.GRU
        self.rnn = rnn_cls(emb_dim, hidden, batch_first=True, bidirectional=bidirectional)
        out_dim = hidden * (2 if bidirectional else 1)
        self.drop = nn.Dropout(dropout)
        self.fc = nn.Linear(out_dim, num_classes)

    def forward(self, batch):
        x, lens = batch["flat"], batch["flat_len"]
        emb = self.drop(self.embedding(x))
        out, hn = self.rnn(_pack(emb, lens))
        if self.pooling == "max":
            out, _ = pad_packed_sequence(out, batch_first=True, total_length=x.shape[1])
            mask = torch.arange(x.shape[1], device=x.device)[None] < lens[:, None]
            doc = _masked_max(out, mask)
        else:
            if self.cell == "lstm":
                hn = hn[0]
            doc = torch.cat([hn[-2], hn[-1]], -1) if self.bidirectional else hn[-1]
        return self.fc(self.drop(doc)), None


# --------------------------------------------------------------------------- #
# Hierarchical model
# --------------------------------------------------------------------------- #
class WordEncoder(nn.Module):
    """BiGRU over the words of each sentence -> one vector per sentence."""

    def __init__(self, emb_dim: int, hidden: int, pooling: str = "last"):
        super().__init__()
        self.pooling = pooling
        self.gru = nn.GRU(emb_dim, hidden, batch_first=True, bidirectional=True)
        self.out_dim = 2 * hidden
        if pooling == "attn":
            self.attn = AdditiveAttention(self.out_dim)

    def forward(self, emb: torch.Tensor, lens: torch.Tensor) -> torch.Tensor:
        W = emb.shape[1]
        out, h = self.gru(_pack(emb, lens))
        if self.pooling == "last":
            return torch.cat([h[0], h[1]], -1)
        out, _ = pad_packed_sequence(out, batch_first=True, total_length=W)
        mask = torch.arange(W, device=emb.device)[None] < lens[:, None]
        if self.pooling == "mean":
            return _masked_mean(out, mask)
        if self.pooling == "max":
            return _masked_max(out, mask)
        return self.attn(out, mask)[0]


class HierAttnGRU(nn.Module):
    def __init__(self, vocab_size, emb_dim=200, word_hidden=128, sent_hidden=256,
                 word_pooling="last", use_sent_rnn=True, sent_pool="attn",
                 dropout=0.3, num_classes=2):
        super().__init__()
        if not use_sent_rnn and sent_pool == "last":
            raise ValueError("sent_pool='last' needs the sentence-level GRU")
        self.use_sent_rnn, self.sent_pool = use_sent_rnn, sent_pool
        self.has_attention = sent_pool == "attn"
        self.embedding = _make_embedding(vocab_size, emb_dim)
        self.word_enc = WordEncoder(emb_dim, word_hidden, word_pooling)
        d = self.word_enc.out_dim
        if use_sent_rnn:
            self.sent_rnn = nn.GRU(d, sent_hidden, batch_first=True)   # unidirectional
        else:
            self.sent_proj = nn.Linear(d, sent_hidden)
        if sent_pool == "attn":
            self.sent_attn = AdditiveAttention(sent_hidden)
        self.drop = nn.Dropout(dropout)
        self.fc = nn.Linear(sent_hidden, num_classes)

    def forward(self, batch):
        hier, sent_len, n_sents = batch["hier"], batch["sent_len"], batch["n_sents"]
        B, S, _ = hier.shape
        valid = sent_len > 0                                   # skip padding sentences entirely
        emb = self.drop(self.embedding(hier[valid]))           # (N_valid, W, E)
        vecs = self.word_enc(emb, sent_len[valid])             # (N_valid, 2*Hw)
        sent_vecs = vecs.new_zeros(B, S, vecs.shape[-1])
        sent_vecs[valid] = vecs
        sent_vecs = self.drop(sent_vecs)

        mask = torch.arange(S, device=hier.device)[None] < n_sents[:, None]
        if self.use_sent_rnn:
            out, h = self.sent_rnn(_pack(sent_vecs, n_sents))
            out, _ = pad_packed_sequence(out, batch_first=True, total_length=S)
            last = h[-1]
        else:
            out, last = torch.tanh(self.sent_proj(sent_vecs)), None

        alpha = None
        if self.sent_pool == "attn":
            doc, alpha = self.sent_attn(out, mask)
        elif self.sent_pool == "last":
            doc = last
        else:
            doc = _masked_mean(out, mask)
        return self.fc(self.drop(doc)), alpha


# --------------------------------------------------------------------------- #
def build_model(name: str, vocab_size: int, cfg: Config) -> nn.Module:
    if name not in MODEL_SPECS:
        raise ValueError(f"unknown model '{name}'. Choose from {list(MODEL_SPECS)}")
    spec = dict(MODEL_SPECS[name])
    kind = spec.pop("kind")
    if kind == "flat":
        return FlatRNN(vocab_size, cfg.emb_dim, cfg.flat_hidden, dropout=cfg.dropout, **spec)
    return HierAttnGRU(vocab_size, cfg.emb_dim, cfg.word_hidden, cfg.sent_hidden,
                       word_pooling=cfg.word_pooling, dropout=cfg.dropout, **spec)
