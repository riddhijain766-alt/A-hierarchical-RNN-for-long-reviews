"""Run the full study: every model x every seed, then the analysis.

    python -m hier_rnn.experiments --dataset imdb                  # full study
    python -m hier_rnn.experiments --preset smoke                  # 1-minute offline sanity run
    python -m hier_rnn.experiments --dataset imdb --max_train 5000 --epochs 5 --seeds 0 1

Finished runs are skipped (use --force to retrain).
"""
from __future__ import annotations

import argparse
from dataclasses import replace

from . import analyze
from . import config as C
from .models import MODEL_SPECS
from .train import run

DEFAULT_MODELS = ["flat_lstm", "flat_bilstm", "flat_bilstm_max",
                  "hier_gru_noattn", "hier_attn_norec", "hier_gru"]

PRESETS = {
    "smoke": dict(dataset="synthetic", n_synth_train=2000, n_synth_test=800, epochs=4,
                  max_sents=20, emb_dim=64, word_hidden=48, sent_hidden=96, flat_hidden=96,
                  min_freq=1, batch_size=64),
}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    C.add_args(ap, skip=("model", "seed"))
    ap.add_argument("--models", nargs="+", default=DEFAULT_MODELS, choices=list(MODEL_SPECS))
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--preset", choices=list(PRESETS), default=None)
    ap.add_argument("--force", action="store_true", help="retrain even if metrics.json exists")
    ap.add_argument("--skip_analysis", action="store_true")
    args = ap.parse_args(argv)

    base = C.from_namespace(args)
    if args.preset:
        base = replace(base, **PRESETS[args.preset])

    for model in args.models:
        for seed in args.seeds:
            cfg = replace(base, model=model, seed=seed)
            if (cfg.run_dir / "metrics.json").exists() and not args.force:
                print(f"skip {model} seed{seed} (done)")
                continue
            run(cfg)
    if not args.skip_analysis:
        analyze.main(["--exp_dir", str(base.exp_dir)])


if __name__ == "__main__":
    main()
