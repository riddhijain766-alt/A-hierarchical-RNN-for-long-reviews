"""Data pipeline: raw text -> sentences -> tokens -> padded hierarchical batches.

Design points that matter for the research question
---------------------------------------------------
* Both model families receive *exactly the same tokens*. The collate function
  builds a hierarchical view (B, S, W) and a flat view (B, T) of the same
  truncated review, so differences in accuracy cannot come from different input.
* Truncation defaults to ``head_tail``: when a review has more than
  ``max_sents`` sentences we keep the first half and the last half. Plain head
  truncation would silently delete the concluding sentences, which is precisely
  the part of a "negative discussion -> positive conclusion" review that matters.
"""
from __future__ import annotations

import hashlib
import html
import pickle
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

from .config import Config

PAD, UNK = 0, 1
PAD_TOKEN, UNK_TOKEN = "<pad>", "<unk>"

# --------------------------------------------------------------------------- #
# Text -> sentences -> tokens (regex only: no NLTK/spaCy downloads required)
# --------------------------------------------------------------------------- #
_BR_RE = re.compile(r"<br\s*/?>", re.IGNORECASE)
_TAG_RE = re.compile(r"<[^>]+>")
_ABBR_RE = re.compile(r"\b(mr|mrs|ms|dr|prof|vs|jr|sr)\.", re.IGNORECASE)
_SPLIT_RE = re.compile(r"(?<=[.!?])[\"')\]]*\s+|\n+")
_TOKEN_RE = re.compile(r"[a-z0-9]+(?:'[a-z]+)?|[!?]")


def split_sentences(text: str) -> list[str]:
    text = html.unescape(text)
    text = _BR_RE.sub("\n", text)
    text = _TAG_RE.sub(" ", text)
    text = _ABBR_RE.sub(lambda m: m.group(1) + "<DOT>", text)
    parts = _SPLIT_RE.split(text)
    out = [p.replace("<DOT>", ".").strip() for p in parts if p and p.strip()]
    return [p for p in out if _TOKEN_RE.search(p.lower())]


def tokenize(sentence: str) -> list[str]:
    return _TOKEN_RE.findall(sentence.lower())


def process_text(text: str) -> tuple[list[str], list[list[str]]]:
    """Return (raw_sentences, token_sentences); both lists are aligned."""
    raws, toks = [], []
    for s in split_sentences(text):
        t = tokenize(s)
        if t:
            raws.append(s)
            toks.append(t)
    if not toks:                                  # empty / junk review
        raws, toks = [""], [[UNK_TOKEN]]
    return raws, toks


def keep_indices(n: int, max_sents: int, mode: str = "head_tail") -> list[int]:
    """Indices of the sentences that survive truncation."""
    if n <= max_sents:
        return list(range(n))
    if mode == "head":
        return list(range(max_sents))
    if mode == "tail":
        return list(range(n - max_sents, n))
    if mode == "head_tail":
        head = max_sents // 2
        tail = max_sents - head
        return list(range(head)) + list(range(n - tail, n))
    raise ValueError(f"unknown truncation mode: {mode}")


# --------------------------------------------------------------------------- #
# Vocabulary
# --------------------------------------------------------------------------- #
class Vocab:
    def __init__(self, itos: list[str]):
        self.itos = itos
        self.stoi = {t: i for i, t in enumerate(itos)}

    @classmethod
    def build(cls, docs: list[list[list[str]]], max_size: int, min_freq: int) -> "Vocab":
        counts: Counter = Counter()
        for doc in docs:
            for sent in doc:
                counts.update(sent)
        words = [w for w, c in counts.most_common() if c >= min_freq and w != UNK_TOKEN]
        return cls([PAD_TOKEN, UNK_TOKEN] + words[: max_size - 2])

    def encode(self, tok: str) -> int:
        return self.stoi.get(tok, UNK)

    def __len__(self) -> int:
        return len(self.itos)


# --------------------------------------------------------------------------- #
# Raw dataset loading
# --------------------------------------------------------------------------- #
HF_DATASETS = {
    "imdb": ("stanfordnlp/imdb", "text", "label"),
    "yelp_polarity": ("fancyzhx/yelp_polarity", "text", "label"),
    "amazon_polarity": ("fancyzhx/amazon_polarity", "content", "label"),
}


def _subsample(n: int, k: int | None, rng: np.random.Generator) -> np.ndarray:
    if k is None or k >= n:
        return np.arange(n)
    return np.sort(rng.choice(n, size=k, replace=False))


def load_texts(cfg: Config):
    """Return (train_texts, train_labels, test_texts, test_labels)."""
    rng = np.random.default_rng(cfg.data_seed)
    if cfg.dataset == "synthetic":
        from .synthetic import make_synthetic

        tr_x, tr_y = make_synthetic(cfg.n_synth_train, seed=cfg.data_seed)
        te_x, te_y = make_synthetic(cfg.n_synth_test, seed=cfg.data_seed + 1)
        return tr_x, tr_y, te_x, te_y
    if cfg.dataset == "csv":
        import pandas as pd

        tr = pd.read_csv(Path(cfg.csv_dir) / "train.csv")
        te = pd.read_csv(Path(cfg.csv_dir) / "test.csv")
        tr_x, tr_y = tr["text"].astype(str).tolist(), tr["label"].astype(int).tolist()
        te_x, te_y = te["text"].astype(str).tolist(), te["label"].astype(int).tolist()
    elif cfg.dataset in HF_DATASETS:
        from datasets import load_dataset

        repo, tcol, lcol = HF_DATASETS[cfg.dataset]
        ds = load_dataset(repo, cache_dir=str(Path(cfg.data_dir) / "hf"))
        tr_x, tr_y = list(ds["train"][tcol]), list(ds["train"][lcol])
        te_x, te_y = list(ds["test"][tcol]), list(ds["test"][lcol])
    else:
        raise ValueError(f"unknown dataset: {cfg.dataset}")
    i = _subsample(len(tr_x), cfg.max_train, rng)
    j = _subsample(len(te_x), cfg.max_test, rng)
    return ([tr_x[k] for k in i], [tr_y[k] for k in i],
            [te_x[k] for k in j], [te_y[k] for k in j])


@dataclass
class Split:
    toks: list            # list[doc]; doc = list[sentence]; sentence = list[str]
    labels: list
    raws: list = None     # raw sentence strings (kept for the test split only)


def build_splits(cfg: Config) -> dict[str, Split]:
    """Tokenise once and cache. The split is fixed by ``data_seed`` so every
    model / seed is trained and evaluated on identical data."""
    key = "|".join(str(x) for x in [cfg.dataset, cfg.max_train, cfg.max_test, cfg.val_frac,
                                    cfg.data_seed, cfg.n_synth_train, cfg.n_synth_test, cfg.csv_dir])
    cache = Path(cfg.cache_dir) / f"{cfg.dataset}_{hashlib.md5(key.encode()).hexdigest()[:10]}.pkl"
    if cache.exists():
        with open(cache, "rb") as f:
            return pickle.load(f)

    tr_x, tr_y, te_x, te_y = load_texts(cfg)
    rng = np.random.default_rng(cfg.data_seed)
    perm = rng.permutation(len(tr_x))
    n_val = int(round(cfg.val_frac * len(tr_x)))
    val_idx, tr_idx = perm[:n_val], perm[n_val:]

    def proc(texts, labels, keep_raw, desc):
        raws, toks = [], []
        for t in tqdm(texts, desc=f"tokenising {desc}", leave=False):
            r, k = process_text(t)
            toks.append(k)
            if keep_raw:
                raws.append(r)
        return Split(toks, list(labels), raws if keep_raw else None)

    splits = {
        "train": proc([tr_x[i] for i in tr_idx], [tr_y[i] for i in tr_idx], False, "train"),
        "val": proc([tr_x[i] for i in val_idx], [tr_y[i] for i in val_idx], False, "val"),
        "test": proc(te_x, te_y, True, "test"),
    }
    cache.parent.mkdir(parents=True, exist_ok=True)
    with open(cache, "wb") as f:
        pickle.dump(splits, f)
    return splits


# --------------------------------------------------------------------------- #
# Torch dataset / collate
# --------------------------------------------------------------------------- #
class DocDataset(Dataset):
    def __init__(self, split: Split, vocab: Vocab, max_sents: int, max_words: int,
                 truncation: str = "head_tail"):
        self.docs, self.labels = [], list(split.labels)
        for sents in split.toks:
            kept = keep_indices(len(sents), max_sents, truncation)
            self.docs.append([[vocab.encode(w) for w in sents[i][:max_words]] for i in kept])

    def __len__(self) -> int:
        return len(self.docs)

    def __getitem__(self, i: int):
        return self.docs[i], self.labels[i], i


def collate_docs(batch) -> dict[str, torch.Tensor]:
    docs, labels, idxs = zip(*batch)
    B = len(docs)
    S = max(len(d) for d in docs)
    W = max(len(s) for d in docs for s in d)
    T = max(sum(len(s) for s in d) for d in docs)
    hier = np.zeros((B, S, W), dtype=np.int64)
    sent_len = np.zeros((B, S), dtype=np.int64)
    flat = np.zeros((B, T), dtype=np.int64)
    n_sents = np.zeros(B, dtype=np.int64)
    flat_len = np.zeros(B, dtype=np.int64)
    for b, d in enumerate(docs):
        pos = 0
        for i, s in enumerate(d):
            L = len(s)
            hier[b, i, :L] = s
            sent_len[b, i] = L
            flat[b, pos:pos + L] = s
            pos += L
        n_sents[b], flat_len[b] = len(d), pos
    return {
        "hier": torch.from_numpy(hier), "sent_len": torch.from_numpy(sent_len),
        "n_sents": torch.from_numpy(n_sents), "flat": torch.from_numpy(flat),
        "flat_len": torch.from_numpy(flat_len),
        "y": torch.tensor(labels, dtype=torch.long), "idx": torch.tensor(idxs, dtype=torch.long),
    }


def to_device(batch: dict, device) -> dict:
    return {k: v.to(device) for k, v in batch.items()}


def make_loader(ds: Dataset, batch_size: int, shuffle: bool, seed: int = 0,
                num_workers: int = 0) -> DataLoader:
    g = torch.Generator()
    g.manual_seed(seed)
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, collate_fn=collate_docs,
                      generator=g if shuffle else None, num_workers=num_workers)
