"""Synthetic reviews with *known* discourse structure.

Used for (a) offline smoke tests / CI and (b) a controlled sanity check of the
research question: three review "kinds" are generated whose gold label is
decided in different ways.

kind          how the gold label is decided
------------  ----------------------------------------------------------------
consistent    every polar sentence agrees with the label
mixed         both polarities occur; the label follows the majority
turnaround    long negative discussion, then a positive conclusion (or vice
              versa). The label follows the *conclusion*, the majority of the
              sentences point the other way.

Lengths are log-normal so that the corpus contains both short and long reviews.
This is a toy: real conclusions come from `--dataset imdb`.
"""
from __future__ import annotations

import numpy as np

POS_ADJ = ["brilliant", "wonderful", "superb", "excellent", "charming", "moving",
           "gorgeous", "hilarious", "fantastic", "delightful", "terrific", "stunning",
           "engaging", "memorable", "beautiful", "impressive"]
NEG_ADJ = ["boring", "awful", "terrible", "dull", "clumsy", "forgettable",
           "ridiculous", "painful", "disappointing", "lazy", "messy", "tedious",
           "annoying", "weak", "shallow", "lifeless"]
NOUNS = ["acting", "plot", "script", "soundtrack", "cinematography", "pacing",
         "dialogue", "ending", "direction", "cast", "story", "characters",
         "humor", "visuals", "editing", "opening"]

POS_T = ["The {n} was {a}.", "I thought the {n} was {a}!", "Honestly the {n} felt {a}.",
         "The {n} is {a}, no doubt about it.", "Every scene of the {n} was {a}."]
NEG_T = ["The {n} was {a}.", "I thought the {n} was {a}.", "Honestly the {n} felt {a}.",
         "The {n} is {a}, sadly.", "Every scene of the {n} was {a}."]
NEUTRAL = ["I saw this with a friend last weekend.", "The theater was half empty.",
           "It runs for about two hours.", "My cousin recommended it to me.",
           "There are a few subplots.", "The film is set in a small town.",
           "I watched it on a rainy evening.", "It was released a few years ago.",
           "Some scenes were shot on location.", "I bought a ticket at the door."]
POS_CONC = ["Overall, a {a} film and I loved it.", "In the end, it was {a} and worth every minute.",
            "All things considered, I really enjoyed it.", "So yes, a {a} experience and I recommend it."]
NEG_CONC = ["Overall, a {a} film and I hated it.", "In the end, it was {a} and a waste of time.",
            "All things considered, I really disliked it.", "So no, a {a} experience and I do not recommend it."]
TAIL = ["That is all I have to say.", "Thanks for reading.", "Anyway, that is my take."]


def _polar(rng, positive: bool) -> str:
    t = POS_T if positive else NEG_T
    adj = POS_ADJ if positive else NEG_ADJ
    return rng.choice(t).format(n=rng.choice(NOUNS), a=rng.choice(adj))


def _conclusion(rng, positive: bool) -> str:
    t = POS_CONC if positive else NEG_CONC
    adj = POS_ADJ if positive else NEG_ADJ
    return rng.choice(t).format(a=rng.choice(adj))


def _make_doc(rng: np.random.Generator, kind: str, y: int) -> list[str]:
    n = int(np.clip(rng.lognormal(mean=2.3, sigma=0.5), 4, 40))
    pos = bool(y)
    sents: list[str] = []
    if kind == "consistent":
        for _ in range(n):
            sents.append(_polar(rng, pos) if rng.random() < 0.7 else rng.choice(NEUTRAL))
        if rng.random() < 0.5:
            sents.append(_conclusion(rng, pos))
    elif kind == "mixed":
        n_polar = max(4, int(round(0.7 * n)))
        n_major = max(int(round(0.65 * n_polar)), n_polar // 2 + 1)
        pol = [pos] * n_major + [not pos] * (n_polar - n_major)
        pol += [None] * (n - n_polar)
        rng.shuffle(pol)
        sents = [_polar(rng, p) if p is not None else rng.choice(NEUTRAL) for p in pol]
    else:  # turnaround
        n_conc = int(rng.integers(1, 3))
        for _ in range(max(3, n - n_conc)):
            sents.append(_polar(rng, not pos) if rng.random() < 0.75 else rng.choice(NEUTRAL))
        for _ in range(n_conc):
            sents.append(_conclusion(rng, pos))
        if rng.random() < 0.3:                      # distractor tail after the conclusion
            sents += list(rng.choice(TAIL, size=int(rng.integers(1, 3))))
    return sents


def make_synthetic(n: int, seed: int, label_noise: float = 0.02):
    """Return (texts, labels) with ~40% consistent, 30% mixed, 30% turnaround."""
    rng = np.random.default_rng(seed)
    kinds = rng.choice(["consistent", "mixed", "turnaround"], size=n, p=[0.4, 0.3, 0.3])
    labels = rng.integers(0, 2, size=n)
    texts = [" ".join(_make_doc(rng, k, int(y))) for k, y in zip(kinds, labels)]
    flip = rng.random(n) < label_noise
    labels = np.where(flip, 1 - labels, labels)
    return texts, labels.astype(int).tolist()
