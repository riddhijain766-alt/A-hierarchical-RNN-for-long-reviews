import numpy as np

from hier_rnn.subsets import SubsetParams, annotate, structure_features
from hier_rnn.data import process_text

P = SubsetParams()


def test_turnaround_detected():
    pol = np.array([-0.7, -0.6, -0.5, -0.6, 0.8, 0.7])      # negative discussion, positive end
    f = structure_features(pol, label=1, p=P)
    assert f["turnaround"] and f["neg_to_pos"] and not f["pos_to_neg"]


def test_turnaround_requires_conclusion_to_match_label():
    pol = np.array([-0.7, -0.6, -0.5, -0.6, 0.8, 0.7])
    assert not structure_features(pol, label=0, p=P)["turnaround"]   # label follows the early part


def test_mixed_detected_and_consistent_not():
    mixed = np.array([0.6, -0.6, 0.7, -0.5, 0.0, 0.6])
    assert structure_features(mixed, 1, P)["mixed"]
    consistent = np.array([0.6, 0.7, 0.5, 0.0, 0.6, 0.4])
    f = structure_features(consistent, 1, P)
    assert not f["mixed"] and not f["turnaround"]


def test_annotate_on_real_text():
    texts = [
        "The acting was awful. The plot was boring and dull. I hated the script. "
        "The pacing was terrible. But the ending was brilliant and wonderful. "
        "Overall I loved it!",
        "Great movie. Wonderful cast. Superb story. I loved every minute. Fantastic ending.",
    ]
    proc = [process_text(t) for t in texts]
    df = annotate([r for r, _ in proc], [t for _, t in proc], [1, 1])
    assert bool(df.loc[0, "turnaround"]) and not bool(df.loc[1, "turnaround"])
    assert {"long", "short", "mixed", "consistent", "neg_to_pos"} <= set(df.columns)
