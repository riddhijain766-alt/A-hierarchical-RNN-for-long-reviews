"""End-to-end on tiny synthetic data: train two models, run the analysis."""
from dataclasses import replace
from pathlib import Path

from hier_rnn import analyze
from hier_rnn.config import Config
from hier_rnn.train import run


def test_train_and_analyze(tmp_path: Path):
    base = Config(dataset="synthetic", n_synth_train=300, n_synth_test=200, epochs=2,
                  emb_dim=16, word_hidden=8, sent_hidden=16, flat_hidden=16, min_freq=1,
                  max_sents=12, batch_size=32, results_dir=str(tmp_path / "res"),
                  cache_dir=str(tmp_path / "cache"))
    for model in ["flat_lstm", "hier_gru"]:
        m = run(replace(base, model=model, seed=0), verbose=False)
        assert 0.0 <= m["test_acc"] <= 1.0
    for seed in (0,):
        assert (base.exp_dir / "hier_gru" / f"seed{seed}" / "attention.pkl").exists()
    analyze.main(["--exp_dir", str(base.exp_dir), "--n_boot", "50"])
    out = base.exp_dir / "analysis"
    for f in ["overall.md", "subsets.md", "pairwise_vs_flat_lstm.md", "fig_subsets.png",
              "fig_length.png", "fig_attention_position.png"]:
        assert (out / f).exists(), f


def test_csv_dataset_path(tmp_path: Path):
    """Custom data: train.csv / test.csv with columns text,label."""
    import pandas as pd
    from hier_rnn.synthetic import make_synthetic

    d = tmp_path / "csv"
    d.mkdir()
    for name, n, seed in [("train", 200, 1), ("test", 100, 2)]:
        x, y = make_synthetic(n, seed)
        pd.DataFrame({"text": x, "label": y}).to_csv(d / f"{name}.csv", index=False)
    cfg = Config(dataset="csv", csv_dir=str(d), epochs=1, emb_dim=16, word_hidden=8, sent_hidden=16,
                 min_freq=1, model="hier_gru", results_dir=str(tmp_path / "r"),
                 cache_dir=str(tmp_path / "c"))
    assert run(cfg, verbose=False)["test_acc"] >= 0.0
    assert (cfg.exp_dir / "test_annotations.csv").exists()
