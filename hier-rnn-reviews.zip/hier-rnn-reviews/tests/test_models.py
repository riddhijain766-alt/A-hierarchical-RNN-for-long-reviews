import pytest
import torch

from hier_rnn.config import Config
from hier_rnn.data import collate_docs
from hier_rnn.models import MODEL_SPECS, build_model

CFG = Config(emb_dim=16, word_hidden=8, sent_hidden=12, flat_hidden=12, dropout=0.0)
DOC_A = [[2, 3, 4], [5, 6]]
DOC_B = [[7, 8, 9, 10], [11], [12, 13], [14, 15, 16], [17, 18]]


@pytest.mark.parametrize("name", list(MODEL_SPECS))
def test_forward_shapes(name):
    m = build_model(name, 30, CFG).eval()
    logits, alpha = m(collate_docs([(DOC_A, 0, 0), (DOC_B, 1, 1)]))
    assert logits.shape == (2, 2)
    assert (alpha is not None) == m.has_attention


@pytest.mark.parametrize("name", list(MODEL_SPECS))
def test_padding_does_not_change_output(name):
    """A review must get the same logits alone or batched next to a longer one."""
    torch.manual_seed(0)
    m = build_model(name, 30, CFG).eval()
    alone, _ = m(collate_docs([(DOC_A, 0, 0)]))
    batched, _ = m(collate_docs([(DOC_A, 0, 0), (DOC_B, 1, 1)]))
    assert torch.allclose(alone[0], batched[0], atol=1e-4)


def test_attention_is_a_distribution_over_real_sentences():
    m = build_model("hier_gru", 30, CFG).eval()
    _, alpha = m(collate_docs([(DOC_A, 0, 0), (DOC_B, 1, 1)]))
    assert torch.allclose(alpha.sum(-1), torch.ones(2), atol=1e-5)
    assert alpha[0, 2:].abs().sum() == 0          # padded sentences get zero weight


def test_gradients_flow_to_all_params():
    m = build_model("hier_gru", 30, CFG)
    logits, _ = m(collate_docs([(DOC_A, 0, 0), (DOC_B, 1, 1)]))
    logits.sum().backward()
    missing = [n for n, p in m.named_parameters() if p.grad is None]
    assert not missing


def test_invalid_ablation_combo():
    from hier_rnn.models import HierAttnGRU
    with pytest.raises(ValueError):
        HierAttnGRU(30, use_sent_rnn=False, sent_pool="last")
