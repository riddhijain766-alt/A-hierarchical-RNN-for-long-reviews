from hier_rnn.data import (Vocab, collate_docs, keep_indices, process_text, split_sentences,
                           tokenize)


def test_sentence_split_basic():
    s = split_sentences("Mr. Smith loved it. It was great! Was it? Yes...")
    assert s == ["Mr. Smith loved it.", "It was great!", "Was it?", "Yes..."]


def test_sentence_split_html_breaks():
    assert split_sentences("Good movie.<br /><br />Bad ending") == ["Good movie.", "Bad ending"]


def test_decimals_not_split():
    assert len(split_sentences("I gave it 7.5 out of 10 stars.")) == 1


def test_tokenize_keeps_exclamation():
    assert tokenize("Great film!") == ["great", "film", "!"]


def test_empty_review_is_safe():
    raws, toks = process_text("   ...   ")
    assert len(raws) == len(toks) == 1


def test_head_tail_keeps_conclusion():
    assert keep_indices(10, 4, "head_tail") == [0, 1, 8, 9]
    assert keep_indices(10, 4, "head") == [0, 1, 2, 3]
    assert keep_indices(10, 4, "tail") == [6, 7, 8, 9]
    assert keep_indices(3, 4, "head_tail") == [0, 1, 2]


def test_vocab_and_collate_views_match():
    vocab = Vocab.build([[["a", "b"], ["b", "c"]]] * 3, max_size=10, min_freq=1)
    d1 = [[2, 3, 4], [5, 6]]
    d2 = [[7]]
    b = collate_docs([(d1, 1, 0), (d2, 0, 1)])
    assert b["hier"].shape == (2, 2, 3)
    assert b["n_sents"].tolist() == [2, 1]
    assert b["flat_len"].tolist() == [5, 1]
    # flat view = the same tokens, concatenated in order
    assert b["flat"][0, :5].tolist() == [2, 3, 4, 5, 6]
    assert b["sent_len"].tolist() == [[3, 2], [1, 0]]
    assert vocab.encode("zzz") == 1
