# Hierarchical RNN for Long Reviews

> Does a **hierarchical recurrent model** (word BiGRU → sentence GRU → sentence attention) beat a
> **single flat LSTM** when reviews are **long**, contain **mixed opinions**, or **end positively after a
> negative discussion**?

A review is not a bag of tokens: its sentiment often depends on *how its sentences relate* — a
complaint followed by "but overall I loved it" is a positive review. This repository is a small,
reproducible study of that question. It is built so that the comparison is **controlled** (same
tokens, same split, same seeds, same optimiser for every model) and so that the answer is reported
**per review type**, not just as one overall accuracy number.

```
 flat baseline                              hierarchical model (proposed)
 ─────────────                              ─────────────────────────────
 all tokens ─► LSTM ─► h_T ─► softmax       sentence 1: words ─► BiGRU ─► s₁ ┐
 (one pass over ~200–1000 tokens)           sentence 2: words ─► BiGRU ─► s₂ ┤► sentence-level GRU ─► h₁..h_S
                                            …                                ┤                         │
                                            sentence S: words ─► BiGRU ─► s_S┘        attention α_i over sentences
                                                                                                       │
                                                                                      Σ α_i h_i ─► softmax
```

## What is compared

| model | description | role |
|---|---|---|
| `flat_lstm` | one unidirectional LSTM over all tokens, last hidden state | **the baseline** in the research question |
| `flat_bilstm` | bidirectional version | stronger baseline |
| `flat_bilstm_max` | BiLSTM + max-pooling over time | strongest flat baseline (is it just pooling?) |
| `hier_gru` | word BiGRU → sentence GRU → **sentence attention** | **proposed model** |
| `hier_gru_noattn` | same, classify from the last sentence-GRU state | ablation: is *attention* needed? |
| `hier_attn_norec` | word BiGRU → sentence attention, **no** sentence GRU | ablation: is *recurrence across sentences* needed? |

The two ablations are what make the study about **document structure and long-range context**, and
not just "a different recurrent cell": if `hier_attn_norec` matches `hier_gru`, sentence-level
recurrence isn't doing the work; if `flat_bilstm_max` matches `hier_gru`, hierarchy isn't either.

## Experimental design

* **Same input for everyone.** The collate function builds a hierarchical view `(B, S, W)` and a flat view
  `(B, T)` from the *same* truncated review (`max_sents=30`, `max_words=50` by default).
* **Truncation keeps the conclusion.** Reviews with more than `max_sents` sentences keep the first half
  *and* the last half (`--truncation head_tail`). Plain head-truncation would delete exactly the
  concluding sentences that the "negative → positive" case depends on.
* **Fixed split, multiple seeds.** `data_seed` fixes train/val/test; models are trained with seeds 0, 1, 2
  (configurable). Checkpoints are selected on validation accuracy; the test set is touched once.
* **Review types are defined by an independent tool**, not by the models. Each test review is annotated
  with [VADER](https://github.com/cjhutto/vaderSentiment) sentence polarities (full, un-truncated review):

| subset | definition (all thresholds in `subsets.py:SubsetParams`) |
|---|---|
| `long` / `short` | ≥ 75th / ≤ 25th percentile of token count |
| `mixed` | ≥ 4 polar sentences, minority polarity ≥ 30 % of them |
| `turnaround` | first 60 % of sentences and the rest have opposite mean polarity **and** the later part agrees with the gold label (the conclusion decides) |
| `neg_to_pos` / `pos_to_neg` | `turnaround` split by gold label (`neg_to_pos` = "positive conclusion after negative discussion") |
| `consistent` | neither `mixed` nor `turnaround` (control group) |
| `long_mixed`, `long_turnaround` | intersections with `long` |

* **Statistics.** For each (model, subset) the report gives mean ± std over seeds, the accuracy difference
  to `flat_lstm` with a **95 % paired-bootstrap CI** over test reviews, and the number of seeds in which the
  model beat the baseline. Subsets with fewer than 100 reviews are flagged.
* **Attention analysis.** For `hier_gru` the pipeline measures how much attention mass falls on the *final
  20 % of sentences* and on the *last sentence*, per review type — does the model learn to look at the
  conclusion when the conclusion decides the label?

### Hypotheses

* **H1 (length):** the hierarchical advantage grows with review length (the flat LSTM has to carry
  information across hundreds of steps; the sentence-level GRU only across ~10–30).
* **H2 (mixed opinions):** the hierarchical model is better on `mixed` than on `consistent`.
* **H3 (conclusion):** on `neg_to_pos` the hierarchical model is better *and* shifts attention towards
  the final sentences.

These are hypotheses, not results — the code is built so they can fail. Null and negative results are
fully reported by the same tables.

## Quick start

```bash
git clone <your-repo-url> && cd hier-rnn-reviews
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt && pip install -e .

# 1) offline sanity check on synthetic data (no downloads)
python -m hier_rnn.experiments --preset smoke

# 2) the real study on IMDB (downloads from Hugging Face the first time; GPU recommended)
python -m hier_rnn.experiments --dataset imdb

# faster variant while iterating
python -m hier_rnn.experiments --dataset imdb --max_train 8000 --epochs 6 --seeds 0 1 --tag _small
```

`make smoke`, `make imdb`, `make test` are shortcuts (see `Makefile`).

Everything is a CLI flag (`python -m hier_rnn.train --help`): hidden sizes, `--word_pooling
{last,mean,max,attn}`, `--truncation {head,tail,head_tail}`, `--glove path/to/glove.6B.200d.txt`, …

### Other datasets

```bash
python -m hier_rnn.experiments --dataset yelp_polarity --max_train 50000 --max_test 10000
python -m hier_rnn.experiments --dataset amazon_polarity --max_train 50000 --max_test 10000
python -m hier_rnn.experiments --dataset csv --csv_dir my_data/      # train.csv, test.csv with columns text,label
```

IMDB (≈230 words/review on average, a long tail beyond 500) is the main benchmark because it has long
reviews; Yelp/Amazon polarity are much shorter, so expect smaller or no hierarchy effects there — which is
itself informative for H1.

### Look inside a trained model

```bash
python -m hier_rnn.predict --ckpt results/imdb/hier_gru/seed0/model.pt \
  --text "The first hour was a slog and the dialogue was clumsy. The acting was weak. But the ending was superb and I loved it."
```
prints the prediction and a bar per sentence showing its attention weight (`--html out.html` for a heat-map).

## Outputs

```
results/<dataset>/
├── test_annotations.csv          per-review structure features and subset flags
├── <model>/seed<k>/              metrics.json, preds.csv, attention.pkl, model.pt
└── analysis/
    ├── overall.md                accuracy / F1 / #params per model
    ├── subsets.md                accuracy per review type per model
    ├── pairwise_vs_flat_lstm.md  Δacc with bootstrap CI and seeds-won
    ├── attention_stats.md        attention on the conclusion per review type
    └── fig_subsets.png  fig_length.png  fig_attention_position.png
```

## Repository layout

```
src/hier_rnn/
  config.py       all hyper-parameters (dataclass) → CLI flags
  data.py         sentence splitting, vocab, head/tail truncation, hierarchical+flat collate
  synthetic.py    controlled toy reviews (consistent / mixed / turnaround)
  models.py       FlatRNN, HierAttnGRU (+ ablations), AdditiveAttention
  subsets.py      VADER-based review-type definitions
  train.py        one model × one seed
  experiments.py  all models × all seeds → analysis
  analyze.py      tables, bootstrap CIs, figures, attention statistics
  predict.py      attention inspection for any text
tests/            27 tests (padding invariance, attention is a distribution, subset logic, e2e smoke)
```

## Things to know before interpreting results

* **Subset labels are heuristic.** VADER is a lexicon tool; it misreads sarcasm and negation. The
  subsets are therefore *noisy slices*, not ground truth. Change `SubsetParams` and re-run
  `python -m hier_rnn.analyze` to check that conclusions are robust to the thresholds.
* **Subsets overlap and can be small.** The table shows `n` for every subset; check it before reading a gap.
* **Two sources of uncertainty.** The bootstrap CI covers test-set sampling noise; the ± std covers training
  seed noise. Use both, and prefer more seeds (`--seeds 0 1 2 3 4`) for claims about small differences.
* **Capacity is similar but not identical.** Parameter counts are in `overall.md`; the embedding table
  dominates (~6 M) and is shared in size by all models. Use `--flat_hidden / --sent_hidden` to match more tightly.
* **Attention is not an explanation.** High attention shows where the model looks, not necessarily what
  causally drives its decision (Jain & Wallace, 2019). It is used here as a descriptive diagnostic.
* **Synthetic data is a sanity check only.** It confirms that the pipeline runs and that the review-type
  slicing behaves; conclusions about real reviews must come from IMDB-style data.
* The sentence splitter is regex-based (no NLTK/spaCy downloads). It is good on well-punctuated text; IMDB
  reviews with missing punctuation will yield fewer, longer "sentences", which handicaps the hierarchy a bit.

## References

* Yang et al., *Hierarchical Attention Networks for Document Classification*, NAACL 2016.
* Hutto & Gilbert, *VADER: A Parsimonious Rule-based Model for Sentiment Analysis of Social Media Text*, ICWSM 2014.
* Jain & Wallace, *Attention is not Explanation*, NAACL 2019.
* Maas et al., *Learning Word Vectors for Sentiment Analysis* (IMDB), ACL 2011.

## License

MIT
